
<td class="text-center">
    @if ($point)
        <i class="fa fa-check"></i>
    @endif
</td>
<td class="text-center">
    @if (!$point)
        <i class="fa fa-check"></i>
    @endif
</td>
<td>
    {{$progres}}%
</td>