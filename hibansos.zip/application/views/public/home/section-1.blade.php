<section>
    <div>
        <div class="display-1 text-center">
            HIBANSOS
        </div>
        <hr>
        <div>
            <h1 class="h1-responsive font-weight-bolder text-center">
                Selamat Datang
            </h1>
            <h4 class="h4-responsive text-center">
                Hibansos adalah program bantuan dana terkait kegiatan hibah dan bantuan sosial yang diberikan secara selektif oleh pemerintah kabupaten Bogor untuk ide-ide yang diusulkan oleh seluruh masyarakat Kabupaten Bogor
            </h4>
        </div>
        <div class="d-flex">
            <a role="button" href="{{base_url('daftar')}}" class="btn btn-block mt-5 mr-3 btn-blue btn-lg">
                Daftar sekarang
            </a>
            <a href="#section-2" onclick="function f() {
                document.getElementById('section-2').scrollIntoView();
                        }" class="btn btn-block mt-5 btn-main-2 btn-lg">
                Cara pengajuan
            </a>
        </div>
    </div>
</section>