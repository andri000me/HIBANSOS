<td>{{$judulKegiatan}}</td>
<td>{{rupiah($dana)}}</td>
<td>{{rupiah($danaRekomendasiSKPD)}}</td>
<td>{{rupiah($danaEvaluasiTAPD)}}</td>