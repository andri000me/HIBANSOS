<div class="card" id="tabel-informasi">
    <div class="card-body">
        <h3 class="h3-responsive">
            <i class="fas fa-info-circle"></i>
            Informasi
        </h3>
        <table class="table p-1">
            <tbody>
            <tr>
                <th colspan="2" class="p-1 bg-success">Di setujui</th>
            </tr>
            <tr>
                <th colspan="2" class="p-1 bg-danger">Di tolak</th>
            </tr>
            <tr>
                <th colspan="2" class="p-1 bg-warning">Di Revisi</th>
            </tr>
            <tr>
                <th colspan="2" class="p-1 bg-light">Proses</th>
            </tr>
            <tr>
                <th class="p-1">Angka</th><td class="p-1">Pemeriksaan</td>
            </tr>
            <tr>
                <th class="p-1">1</th><td class="p-1">TU</td>
            </tr>
            <tr>
                <th class="p-1">2</th><td class="p-1">SETDA</td>
            </tr>
            <tr>
                <th class="p-1">3</th><td class="p-1">SKPD</td>
            </tr>
            <tr>
                <th class="p-1">4</th><td class="p-1">TAPD</td>
            </tr>
            <tr>
                <th class="p-1">5</th><td class="p-1">BUPATI</td>
            </tr>
            </tbody>
        </table>
    </div>
</div>
