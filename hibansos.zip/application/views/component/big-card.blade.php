<div class="card mx-auto p-0 col-md-12" style="min-height: 50vh">
    <div class="card-body">
        <h1 class="card-header text-uppercase bg-transparent py-4">
            <strong>{{ $title }}</strong>
        </h1>
        {{ $slot }}
    </div>
</div>