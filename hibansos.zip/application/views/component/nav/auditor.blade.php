@component('component.nav.public')@endcomponent
<li class="nav-item">
    <a class="nav-link text-capitalize" href="{{base_url('daftarMonitoring')}}">Monitoring Evaluasi</a>
</li>