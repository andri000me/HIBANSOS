@component('component.nav.public')@endcomponent
<li class="nav-item">
    <a class="nav-link text-capitalize" href="{{base_url('pemeriksaan')}}">pemeriksaan</a>
</li>