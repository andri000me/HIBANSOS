<li class="nav-item">
    <a class="nav-link text-capitalize {{uri_string() == 'tentang' ? 'active' : ''}}" href="{{base_url('tentang')}}">tentang</a>
</li>
<li class="nav-item">
    <a class="nav-link text-capitalize {{uri_string() == 'pencarian' ? 'active' : ''}}" href="{{base_url('pencarian')}}">Proposal hibansos</a>
</li>
<li class="nav-item">
    <a class="nav-link text-capitalize {{uri_string() == 'peraturan' ? 'active' : ''}} " href="{{base_url('peraturan')}}">Peraturan</a>
</li>