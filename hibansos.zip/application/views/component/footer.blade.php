<footer class="page-footer font-small bg-dark">
    <div class="footer-copyright text-center py-3">© 2019 Copyright:
        <a href="{{base_url()}}"> HIBANSOS</a>
    </div>
</footer>